
import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.join(process.cwd(), 'village.db');

export const db = new Database(dbPath, { verbose: console.log });
db.pragma('journal_mode = WAL');

export interface Complaint {
  id: string;
  title: string;
  description: string;
  category: string;
  status: string;
  location_lat: number;
  location_lng: number;
  address: string;
  contact_email: string;
  image_url: string;
  created_at: string;
  updated_at: string;
}

export interface ComplaintUpdate {
  id: number;
  complaint_id: string;
  status_change: string;
  comment: string;
  created_at: string;
}
