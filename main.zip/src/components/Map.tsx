
"use client";

import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix Leaflet marker icon issue in Next.js
const icon = L.icon({
    iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
    iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
    shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41],
});

interface MapProps {
    pos: { lat: number; lng: number } | null;
    setPos?: (pos: { lat: number; lng: number }) => void;
    interactive?: boolean;
}

function LocationMarker({ pos, setPos, interactive }: MapProps) {
    const map = useMapEvents({
        click(e) {
            if (interactive && setPos) {
                setPos(e.latlng);
                map.flyTo(e.latlng, map.getZoom());
            }
        },
    });

    useEffect(() => {
        if (pos) {
            map.flyTo(pos, map.getZoom());
        }
    }, [pos, map]);

    return pos === null ? null : (
        <Marker position={pos} icon={icon}>
            <Popup>Location selected</Popup>
        </Marker>
    );
}

export default function Map({ pos, setPos, interactive = false }: MapProps) {
    // Default to a central location (e.g., India center or generic) if no pos
    const defaultCenter = { lat: 20.5937, lng: 78.9629 };

    return (
        <MapContainer
            center={pos || defaultCenter}
            zoom={13}
            scrollWheelZoom={true}
            className="h-full w-full rounded-md z-0"
        >
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <LocationMarker pos={pos} setPos={setPos} interactive={interactive} />
        </MapContainer>
    );
}
