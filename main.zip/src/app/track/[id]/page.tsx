
import { notFound } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BadgeCheck, Clock, XCircle, AlertCircle, Calendar } from "lucide-react";
import { db, Complaint, ComplaintUpdate } from "@/lib/db";
import dynamic from "next/dynamic";

const MapWrapper = dynamic(() => import("@/components/MapWrapper"));

// Force dynamic rendering
export const dynamicParams = true; // Use this instead of exported 'dynamic' const for newer Next.js if needed overlap

async function getComplaint(id: string) {
    try {
        const complaint = db.prepare('SELECT * FROM complaints WHERE id = ?').get(id) as Complaint | undefined;
        if (!complaint) return null;
        const updates = db.prepare('SELECT * FROM updates WHERE complaint_id = ? ORDER BY created_at DESC').all(id) as ComplaintUpdate[];
        return { ...complaint, updates };
    } catch (e) {
        console.error(e);
        return null;
    }
}

export default async function TrackingDetailsPage({ params }: { params: { id: string } }) {
    const { id } = await Promise.resolve(params); // Await params
    const complaint = await getComplaint(id);

    if (!complaint) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50">
                <h1 className="text-2xl font-bold text-red-600 mb-4">Complaint Not Found</h1>
                <p className="text-gray-600 mb-8">ID {id} not found.</p>
                <Link href="/track"><Button>Try Another ID</Button></Link>
            </div>
        );
    }

    const getStatusColor = (status: string) => {
        switch (status.toLowerCase()) {
            case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
            case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
            case 'in progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            default: return 'bg-blue-100 text-blue-800 border-blue-200';
        }
    };

    const hasLocation = complaint.location_lat && complaint.location_lng;

    return (
        <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto space-y-6">
                <div className="flex justify-between items-center">
                    <h1 className="text-2xl font-bold">Complaint Details</h1>
                    <Link href="/track"><Button variant="outline">Back to Search</Button></Link>
                </div>

                <Card>
                    <CardHeader>
                        <div className="flex justify-between items-start">
                            <div>
                                <CardTitle className="text-xl">{complaint.title}</CardTitle>
                                <CardDescription className="mt-1">ID: <span className="font-mono text-xs">{complaint.id}</span></CardDescription>
                            </div>
                            <div className={`px-3 py-1 rounded-full border text-sm font-medium ${getStatusColor(complaint.status)}`}>{complaint.status}</div>
                        </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="col-span-1 md:col-span-2">
                                <h3 className="text-sm font-medium text-gray-500">Description</h3>
                                <p className="mt-1 whitespace-pre-wrap">{complaint.description}</p>
                            </div>
                            {/* Map View */}
                            {hasLocation && (
                                <div className="col-span-1 md:col-span-2">
                                    <h3 className="text-sm font-medium text-gray-500 mb-2">Location Map</h3>
                                    <div className="h-64 rounded-md border overflow-hidden relative">
                                        <MapWrapper pos={{ lat: complaint.location_lat, lng: complaint.location_lng }} />
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">{complaint.address}</p>
                                </div>
                            )}
                        </div>
                        {complaint.image_url && (
                            <div>
                                <h3 className="text-sm font-medium text-gray-500 mb-2">Evidence</h3>
                                <img src={complaint.image_url} alt="Problem Evidence" className="w-full h-auto max-h-96 object-cover rounded-md border" />
                            </div>
                        )}
                    </CardContent>
                </Card>

                <h2 className="text-lg font-bold mt-8">Updates & Activity</h2>
                <div className="space-y-4">
                    {complaint.updates && complaint.updates.length > 0 ? (
                        complaint.updates.map((update: any) => (
                            <Card key={update.id}>
                                <CardHeader className="py-4">
                                    <div className="flex justify-between">
                                        <span className="font-medium text-sm">Status: {update.status_change}</span>
                                        <span className="text-xs text-gray-500">{new Date(update.created_at).toLocaleString()}</span>
                                    </div>
                                </CardHeader>
                                <CardContent className="py-2 pb-4 text-sm text-gray-600">{update.comment}</CardContent>
                            </Card>
                        ))
                    ) : <p className="text-gray-500 italic text-center py-4">No updates yet.</p>}
                </div>
            </div>
        </div>
    );
}
