
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Upload, Loader2, CheckCircle2 } from "lucide-react";
import dynamic from "next/dynamic";

const MapWrapper = dynamic(() => import("@/components/MapWrapper"), { ssr: false });

export default function ReportPage() {
    const router = useRouter();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
    const [locationLoading, setLocationLoading] = useState(false);
    const [selectedImage, setSelectedImage] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);

    const handleGetLocation = () => {
        setLocationLoading(true);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setLocation({
                        lat: position.coords.latitude,
                        lng: position.coords.longitude,
                    });
                    setLocationLoading(false);
                },
                (error) => {
                    console.error("Error getting location:", error);
                    alert("Could not detect location. Please allow location access or enter address manually.");
                    setLocationLoading(false);
                }
            );
        } else {
            alert("Geolocation is not supported by this browser.");
            setLocationLoading(false);
        }
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setSelectedImage(file);
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setIsSubmitting(true);

        const formData = new FormData(e.currentTarget);
        if (location) {
            formData.append("location_lat", location.lat.toString());
            formData.append("location_lng", location.lng.toString());
        }
        if (selectedImage) {
            formData.append("image", selectedImage);
        }

        try {
            const response = await fetch("/api/complaints", {
                method: "POST",
                body: formData,
            });

            const data = await response.json();

            if (data.success) {
                router.push(`/track/${data.id}`);
            } else {
                alert("Failed to submit complaint. Please try again.");
            }
        } catch (error) {
            console.error("Submission error:", error);
            alert("An error occurred. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto">
                <Button variant="ghost" className="mb-4" onClick={() => router.push("/")}>
                    &larr; Back to Home
                </Button>
                <Card>
                    <CardHeader>
                        <CardTitle className="text-2xl">Report an Issue</CardTitle>
                        <CardDescription>
                            Provide details about the issue you are facing. We will review it shortly.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            {/* Other inputs remain same, skipping for brevity but including essential structure */}
                            <div className="space-y-2">
                                <Label htmlFor="title">Title</Label>
                                <Input id="title" name="title" placeholder="e.g., Pothole on Main Street" required />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="category">Category</Label>
                                <select
                                    id="category"
                                    name="category"
                                    className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm"
                                    required
                                >
                                    <option value="" disabled selected>Select a category</option>
                                    <option value="Roads">Roads & Infrastructure</option>
                                    <option value="Water">Water Supply</option>
                                    <option value="Electricity">Electricity</option>
                                    <option value="Sanitation">Sanitation & Garbage</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="description">Description</Label>
                                <Textarea id="description" name="description" placeholder="Describe the issue..." required />
                            </div>

                            <div className="space-y-2">
                                <Label>Location</Label>
                                <div className="flex flex-col sm:flex-row gap-3 mb-2">
                                    <Input name="address" placeholder="Enter manual address or landmark" className="flex-1" required={!location} />
                                    <Button type="button" variant="secondary" onClick={handleGetLocation} disabled={locationLoading}>
                                        {locationLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <MapPin className="mr-2 h-4 w-4" />}
                                        {location ? "Update Location" : "Detect Location"}
                                    </Button>
                                </div>
                                {/* Map Integration */}
                                <div className="h-64 rounded-md border overflow-hidden relative">
                                    <MapWrapper pos={location} setPos={setLocation} interactive={true} />
                                </div>
                                {location && (
                                    <p className="text-xs text-green-600 flex items-center mt-1">
                                        <CheckCircle2 className="h-3 w-3 mr-1" />
                                        Selected: {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                                    </p>
                                )}
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="image">Upload Photo (Optional)</Label>
                                <Input id="image" type="file" accept="image/*" className="cursor-pointer" onChange={handleImageChange} />
                                {previewUrl && (
                                    <div className="mt-2">
                                        <img src={previewUrl} alt="Preview" className="h-32 w-auto rounded-md object-cover border" />
                                    </div>
                                )}
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="contact_email">Email (Optional)</Label>
                                <Input id="contact_email" name="contact_email" type="email" placeholder="For status updates" />
                            </div>

                            <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
                                {isSubmitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...</> : "Submit Complaint"}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
