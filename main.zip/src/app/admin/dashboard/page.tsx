
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { db } from '@/lib/db';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Complaint } from '@/lib/db';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export const dynamic = 'force-dynamic';

export default async function AdminDashboard() {
    const cookieStore = await cookies();
    if (!cookieStore.get('admin_session')) {
        redirect('/admin/login');
    }

    // Fetch stats
    const total = db.prepare('SELECT COUNT(*) as count FROM complaints').get() as { count: number };
    const pending = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE status = 'Open'").get() as { count: number };
    const resolved = db.prepare("SELECT COUNT(*) as count FROM complaints WHERE status = 'Resolved'").get() as { count: number };

    // Fetch recent
    const recentComplaints = db.prepare('SELECT * FROM complaints ORDER BY created_at DESC LIMIT 5').all() as Complaint[];

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold">Dashboard</h1>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">Total Complaints</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold">{total.count}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">Pending Action</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold text-yellow-600">{pending.count}</div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-muted-foreground">Resolved</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold text-green-600">{resolved.count}</div>
                    </CardContent>
                </Card>
            </div>

            <div>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold">Recent Complaints</h2>
                    <Link href="/admin/complaints">
                        <Button variant="outline" size="sm">
                            View All <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </Link>
                </div>
                <div className="grid gap-4">
                    {recentComplaints.map((c) => (
                        <Card key={c.id}>
                            <CardContent className="flex justify-between items-center p-6">
                                <div>
                                    <p className="font-semibold">{c.title}</p>
                                    <p className="text-sm text-muted-foreground">{c.address || 'No location'} • {new Date(c.created_at).toLocaleDateString()}</p>
                                </div>
                                <div className="flex items-center gap-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium border
                                ${c.status === 'Resolved' ? 'bg-green-50 text-green-700 border-green-200' :
                                            c.status === 'Open' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                                                'bg-blue-50 text-blue-700 border-blue-200'}`}>
                                        {c.status}
                                    </span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}
