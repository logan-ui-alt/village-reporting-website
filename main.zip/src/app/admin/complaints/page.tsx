
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { db } from '@/lib/db';
import { Complaint } from '@/lib/db';
import { Button } from '@/components/ui/button';
import { updateComplaintStatus } from '../actions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Calendar, Camera } from 'lucide-react';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function AdminComplaintsPage() {
    const cookieStore = await cookies();
    if (!cookieStore.get('admin_session')) {
        redirect('/admin/login');
    }

    const complaints = db.prepare('SELECT * FROM complaints ORDER BY created_at DESC').all() as Complaint[];

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold">Manage Complaints</h1>
            </div>

            <div className="space-y-4">
                {complaints.map((c) => (
                    <Card key={c.id} className="overflow-hidden">

                        <div className="flex flex-col md:flex-row">
                            {c.image_url && (
                                <div className="w-full md:w-48 h-48 md:h-auto bg-slate-100 flex-shrink-0">
                                    <img src={c.image_url} alt="Evidence" className="w-full h-full object-cover" />
                                </div>
                            )}
                            <div className="flex-1 p-6">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <h2 className="text-xl font-semibold">{c.title}</h2>
                                            <span className={`px-2 py-0.5 text-xs rounded-full border ${c.status === 'Resolved' ? 'bg-green-100 text-green-700 border-green-200' :
                                                    c.status === 'Rejected' ? 'bg-red-100 text-red-700 border-red-200' :
                                                        'bg-yellow-100 text-yellow-700 border-yellow-200'
                                                }`}>{c.status}</span>
                                        </div>
                                        <p className="text-muted-foreground mt-1 text-sm">{c.description}</p>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-sm text-muted-foreground">
                                    <div className="flex items-center gap-1">
                                        <MapPin className="h-4 w-4" />
                                        <span className="truncate">{c.address || 'No Address'}</span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                        <Calendar className="h-4 w-4" />
                                        <span>{new Date(c.created_at).toLocaleDateString()}</span>
                                    </div>
                                    <div>Category: {c.category}</div>
                                    <div>ID: <span className="font-mono">{c.id}</span></div>
                                </div>

                                <div className="mt-6 flex flex-wrap gap-2 border-t pt-4">
                                    <form action={async () => {
                                        'use server';
                                        await updateComplaintStatus(c.id, 'In Progress', 'Admin marked as In Progress');
                                    }}>
                                        <Button variant="outline" size="sm" disabled={c.status === 'In Progress'}>Mark In Progress</Button>
                                    </form>
                                    <form action={async () => {
                                        'use server';
                                        await updateComplaintStatus(c.id, 'Resolved', 'Issue has been resolved');
                                    }}>
                                        <Button variant="default" size="sm" className="bg-green-600 hover:bg-green-700" disabled={c.status === 'Resolved'}>Mark Resolved</Button>
                                    </form>
                                    <form action={async () => {
                                        'use server';
                                        await updateComplaintStatus(c.id, 'Rejected', 'Issue rejected or duplicate');
                                    }}>
                                        <Button variant="destructive" size="sm" disabled={c.status === 'Rejected'}>Reject</Button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </Card>
                ))}
                {complaints.length === 0 && (
                    <p className="text-center text-muted-foreground py-12">No complaints found.</p>
                )}
            </div>
        </div>
    );
}
