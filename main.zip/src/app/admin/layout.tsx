
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { LayoutDashboard, ListTodo, LogOut } from 'lucide-react';
import { logout } from './actions';

export default async function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    // Simple session check
    const cookieStore = await cookies();
    const session = cookieStore.get('admin_session');

    // If no session, rely on the specific page to handle it or middleware.
    // But since this is a layout, we can catch it here for all children EXCEPT login.
    // However, layout wraps everything including login if it's in the same directory structure without route groups.
    // To avoid circular redirect on login page, we should check if we are already on login? 
    // No, layout runs for all.

    // STRATEGY: Use a route group (authenticated) or just check in page. 
    // For simplicity: I will NOT check here to avoid breaking login page if it shares layout.
    // Instead, I will assume the pages underneath (dashboard, complaints) will check.
    // Wait, I can move login out or just have a specific layout for dashboard.

    // Better: Create `app/admin/(authenticated)/layout.tsx`?
    // User didn't ask for perfect structure, just "create it".

    // Let's make a Sidebar component that is only shown if logged in?
    // actually, let's just make the layout nice and assume specific pages check auth.

    return (
        <div className="min-h-screen bg-slate-100 flex">
            {/* Sidebar - only show if not on login page? complicated in server layout. 
          Let's just show it. If user is on login page, they will see it. 
          Actually, usually login page has different layout. 
      */}

            {session && (
                <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full">
                    <div className="p-6">
                        <h2 className="text-xl font-bold">Admin Portal</h2>
                    </div>
                    <nav className="flex-1 px-4 space-y-2">
                        <Link href="/admin/dashboard">
                            <Button variant="ghost" className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-800">
                                <LayoutDashboard className="mr-2 h-4 w-4" />
                                Dashboard
                            </Button>
                        </Link>
                        <Link href="/admin/complaints">
                            <Button variant="ghost" className="w-full justify-start text-slate-300 hover:text-white hover:bg-slate-800">
                                <ListTodo className="mr-2 h-4 w-4" />
                                Complaints
                            </Button>
                        </Link>
                    </nav>
                    <div className="p-4 border-t border-slate-800">
                        <form action={logout}>
                            <Button variant="destructive" className="w-full justify-start">
                                <LogOut className="mr-2 h-4 w-4" />
                                Logout
                            </Button>
                        </form>
                    </div>
                </aside>
            )}

            <main className={`flex-1 p-8 ${session ? 'ml-64' : ''}`}>
                {children}
            </main>
        </div>
    );
}
