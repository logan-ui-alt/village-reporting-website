'use server'

import { redirect } from 'next/navigation';

export async function login(formData: FormData) {
    const password = formData.get('password');

    // Simple hardcoded check for now - intended to be replaced with real auth later if needed
    if (password === 'admin123') {
        // Set cookie or session here in real app
        redirect('/admin/dashboard');
    }

    return { error: 'Invalid password' };
}
