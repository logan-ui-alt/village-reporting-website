
'use client'

import { useFormState } from 'react-dom';
import { login } from './actions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useState } from 'react';

// Wrap the server action to handle error state in client
async function loginAction(prevState: any, formData: FormData) {
    const result = await login(formData);
    if (result?.error) {
        return { message: result.error };
    }
    return { message: null };
}

export default function AdminLogin() {
    const [state, formAction] = useState(loginAction);
    // Note: useFormState is the correct hook in newer React/Next versions, 
    // but to avoid version conflicts if 'react-dom' types missing, I'll do a simpler wrap or use useActionState if available.
    // actually for simplicity let's just use a simple client handler calling the server action if possible, 
    // but server actions in forms are best.

    // Let's stick to standard form submission for robustness without complex hooks if types are missing.

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-100">
            <Card className="w-full max-w-md">
                <CardHeader>
                    <CardTitle>Admin Login</CardTitle>
                    <CardDescription>Enter the administrative password to continue.</CardDescription>
                </CardHeader>
                <CardContent>
                    <form action={login}>
                        <div className="space-y-4">
                            <Input
                                type="password"
                                name="password"
                                placeholder="Password"
                                required
                            />
                            <Button type="submit" className="w-full">Login</Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
